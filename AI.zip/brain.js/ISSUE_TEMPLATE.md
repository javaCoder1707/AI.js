<!-- If you don't mind add a fun gif or meme, but no pressure -->
![A GIF or MEME to give some spice of the internet](url)

## *What* is wrong?
<!-- Ex. training network takes really long -->

## *Where* does it happen?
<!-- Ex. In the a NeuralNetwork when trying to run a net in node.js on my mac -->

## *How* do we replicate the issue?
<!-- Please be specific as possible. Use dashes (-) or numbers (1.) to create a list of steps -->

## *How* important is this (1-5)?
<!-- On a scale from 1-5 where 5 is the most important how would you rate it? -->

## Expected behavior (i.e. solution)
<!-- What do you think should have happened? -->


## Other Comments
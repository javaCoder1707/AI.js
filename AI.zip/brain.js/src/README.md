# Brain.js Source Files
Welcome!

Brain.js aims to be:
* Javascript and Node based
* an easy, well thought out api
* simple enough to teach a child
* performant enough for enterprise and hobbyists alike

The industry wants you to think neural networks are complex, they are not. 
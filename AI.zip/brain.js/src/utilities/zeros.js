module.exports = function zeros(size) {
  return new Float32Array(size);
};

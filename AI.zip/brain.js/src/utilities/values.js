module.exports = function values(size, value) {
  return new Float32Array(size).fill(value);
}